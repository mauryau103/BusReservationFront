import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  public title:string="Home-Bus Reservation System"

  constructor(private router: Router) { 
   
  }
  goPlaces() {
    this.router.navigate(['/', 'login'])
      .then(nav => {
        console.log(nav); // true if navigation is successful
      }, err => {
        console.log(err) // when there's an error
      });
  }

  ngOnInit(): void {
  }

}
